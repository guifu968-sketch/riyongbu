# 日用簿 · 手机桌面版部署包

这个包是一个静态网页 App，可部署到 GitHub Pages、Cloudflare Pages、Vercel 等免费静态托管平台。部署后，用 iPhone 的 Safari 打开网址，再点「分享」→「添加到主屏幕」，就能像 App 一样从手机桌面进入。

## 文件说明

- `index.html`：账本主程序，支持账单图片。
- `manifest.webmanifest`：手机桌面图标和 PWA 配置。
- `service-worker.js`：离线缓存配置。
- `icons/`：桌面图标。

## 最简单的 GitHub Pages 方法

1. 打开 GitHub，新建一个仓库，例如 `riyongbu`。
2. 把本压缩包里的所有文件上传到仓库根目录。注意：`index.html` 必须在最外层，不要放进二级文件夹。
3. 进入仓库 Settings → Pages。
4. Source 选择 `Deploy from a branch`。
5. Branch 选择 `main`，文件夹选择 `/root`，保存。
6. 等 1–3 分钟，GitHub 会生成一个网址。
7. 用 iPhone Safari 打开该网址 → 分享 → 添加到主屏幕。

## 重要提醒

- 账本数据默认保存在当前浏览器本地，不会自动上传云端。
- 换手机、清浏览器数据、换浏览器前，一定先在账本菜单里「导出 JSON 备份」。
- 带图片的 JSON 文件会比较大，这是正常的。
- 如果你希望多设备同步，需要后续接入云端数据库或 iCloud/Google Drive 备份。
